from chalice import Chalice, Response
from chalice import Chalice
from chalicelib import config

from boto3.dynamodb.conditions import Key, Attr
from jinja2 import Environment, PackageLoader, select_autoescape
from chalicelib import config

import boto3
import os
import json
import time
import urllib
from datetime import datetime

from ebaysdk.trading import Connection as Trading
from ebaysdk.exception import ConnectionError
from ebaysdk.finding import Connection as Finding

from pymemcache.client.base import Client

app = Chalice(app_name='ebay')
app.debug = True


@app.route('/')

def index():
    start = time.time()

    page = 1
    limit = 50
    rows = 3

    env = get_env()

    items = get_items(config.cats[0], limit)

    keywords = get_keywords(items["searchResult"]["item"])
    template = env.get_template('index.html')

    return Response(
        body = template.render(
            keywords = ", ".join(keywords),
            title = config.title,
            description = config.description,
            items = items,
            pages = get_pages(page, int(items["paginationOutput"]["totalPages"])),
            category = config.cats[0],
            current_page = page,
            total_pages = int(items["paginationOutput"]["totalPages"]),
            limit = limit,
            in_rows = int(limit/rows)+1
        ),
        status_code = 200,
        headers = {
            "Content-Type": "text/html"
        }
    )


@app.route('/search/{query}/{page}')
def search(query, page = 1):
    page = int(page)
    limit = 51

    rows = 3
    env = get_env()
    items = get_search_items(query, config.cats[0], 12)

    if limit  == len(items["searchResult"]["item"]):
        in_rows = int(limit/rows)
    else:
        in_rows = int(len(items["searchResult"]["item"])/rows)

    keywords = get_keywords(items["searchResult"]["item"])
    template = env.get_template('index.html')
    return Response(
        body = template.render(
            keywords = ", ".join(keywords),
            title = config.title,
            description = config.description,

            items = items,
            pages = get_pages(page, int(items["paginationOutput"]["totalPages"])),

            query = query,
            current_page = page,
            total_pages = int(items["paginationOutput"]["totalPages"]),
            limit = limit,
            in_rows = in_rows

        ),
        status_code = 200,
        headers = {
            "Content-Type": "text/html"
        }
    )

@app.route('/category/{category}/{page}')
def category(category, page = 1):
    page = int(page)
    env = get_env()
    limit = 50
    items = get_items(category, 50, page)
    rows = 3
    if limit  == len(items["searchResult"]["item"]):
        in_rows = int(limit/rows)
    else:
        in_rows = int(len(items["searchResult"]["item"])/rows)


    keywords = get_keywords(items["searchResult"]["item"])
    template = env.get_template('index.html')
    return Response(
        body = template.render(
            keywords = ", ".join(keywords),
            title = config.title,
            description = config.description,

            items = items,
            pages = get_pages(page, int(items["paginationOutput"]["totalPages"])),

            category = category,
            current_page = page,
            total_pages = int(items["paginationOutput"]["totalPages"]),
            in_rows = in_rows
        ),
        status_code = 200,
        headers = {
            "Content-Type": "text/html"
        }
    )

@app.route('/main.css')
def main_css():

    template = get_template('main.css')
    return Response(
        body = template.render(
        ),
        status_code = 200,
        headers = {
            "Content-Type": "text/css"
        }
    )

@app.route('/reset.css')
def reset_css():

    template = get_template('reset.css')
    return Response(
        body = template.render(
        ),
        status_code = 200,
        headers = {
            "Content-Type": "text/css"
        }
    )

@app.route('/sitemap.xml')
def sitemap():
    template =get_template('sitemap.xml')
    return Response(

        body = template.render(
            queries = ["DJI","Drones","Mavic", "DJI Maciv PRO","Spark" ,"Parrot","Hubsan","GoPro"]
        ),
        status_code = 200,
        headers = {
            "Content-Type": "text/xml"
        }
    )

@app.route('/favicon.ico')
def favicon():
    return Response(body="no", status_code=404, headers={'Content-Type':'text/html'})

def get_search_items(query, cat, limit = 10):
    start = time.time()
    api = Finding(
        domain = 'svcs.ebay.com',
        appid=config.app_id,
        config_file=None,
        siteid="EBAY-US"
    )

    callData = {
        "categoryId": cat,
        "outputSelector": ["GalleryInfo","PictureURLLarge"],
        "paginationInput": {
            "entriesPerPage": limit,
            "pageNumber": 1
        },
        "keywords": urllib.request.unquote(query)

    }

    items = api.execute('findItemsAdvanced', callData).dict()
    send_metric("search_items", time.time() - start)
    return items

find_api = None;

def init_finding_api():
    global find_api
    if find_api  is  None:
        print("init")
        find_api = Finding(
            domain = 'svcs.ebay.com',
            appid=config.app_id,
            config_file=None,
            siteid="EBAY-US"
        )

    return find_api

def get_items(cat, limit = 10, page = 1):
    print(os.environ["MEMCACHED_HOST"])
    client = Client((os.environ["MEMCACHED_HOST"], int(os.environ["MEMCACHED_PORT"])))
    result = client.get("master_of")

    if(result):
        return json.loads(result)
    else:
        start = time.time()
        api = init_finding_api()
        callData = {
            "categoryId": cat,
            "outputSelector": ["GalleryInfo","PictureURLLarge"],
            "paginationInput": {
                "entriesPerPage": limit,
                "pageNumber": page
            }
        }


        items = api.execute('findItemsByCategory', callData).dict()

        send_metric("get_items", time.time() - start)
        client.set('master_of', json.dumps(items))
    return items

def send_metric(name, value):
    cw = boto3.client('cloudwatch')
    metric =  [
            {
                'MetricName': name,
                'Value': value,
                'Unit': 'Milliseconds',
                'StorageResolution': 60
            },
        ]
    response = cw.put_metric_data(
        Namespace='ebay',
        MetricData=metric
    )
    print(metric)
    return {}


def get_keywords(items):
    keywords = []
    for i in items:
        keywords = keywords + i["title"].split()
    return list(set(keywords))

def get_categories(cats):
    result  = []
    for cat in cats:
        dynamodb = get_dynamodb()
        table = dynamodb.Table('ebay_categories')
        response = table.query(
            IndexName="CategoryParentID-index",
            KeyConditionExpression=Key("CategoryParentID").eq(cat)
        )
        items = response['Items']
        result += items
    return result

def get_dynamodb():
    return boto3.resource('dynamodb')

def get_template(template):
    env = get_env()
    return env.get_template(template)

def get_env():
    return Environment(
            loader=PackageLoader('chalicelib', 'templates'),
            autoescape=select_autoescape(['html', 'xml'])
        )

def get_pages(page, total):
    pages = list(range(total))

    pages_first = pages[1:5];
    if page - 3 < 1:
        pages_current = pages[page:page+5]
    else:
        pages_current = pages[page-3:page+5]


    return list(set(pages_first+pages_current))
