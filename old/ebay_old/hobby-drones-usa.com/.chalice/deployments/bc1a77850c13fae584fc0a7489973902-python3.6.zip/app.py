from chalice import Chalice, Response
from chalice import Chalice
from ebaysdk.trading import Connection as Trading
from ebaysdk.exception import ConnectionError
from ebaysdk.finding import Connection as Findin
from boto3.dynamodb.conditions import Key, Attr
from jinja2 import Environment, PackageLoader, select_autoescape
from views import config
import boto3
import os
app = Chalice(app_name='ebay')
app.debug = True

@app.route('/')
def index():
    get_categories(config.cats)
    env = get_env()

    template = env.get_template('index.html')

    return Response(
        body = template.render(
            title = config.title
        ),
        status_code = 200,
        headers = {
            "Content-Type": "text/html"
        }
    )

def get_categories(cats):
    result  = []
    for cat in cats:
        dynamodb = get_dynamodb()
        table = dynamodb.Table('ebay_categories')
        response = table.query(
            IndexName="CategoryParentID-index",
            KeyConditionExpression=Key("CategoryParentID").eq(cat)
        )
        items = response['Items']
        result += items
    return result

@app.route('/favicon.ico')
def favicon():
    return Response(body="no", status_code=404, headers={'Content-Type':'text/html'})



def get_dynamodb():
    return boto3.resource('dynamodb')


def get_env():
    return Environment(
            loader=PackageLoader('views', 'templates'),
            autoescape=select_autoescape(['html', 'xml'])
        )
