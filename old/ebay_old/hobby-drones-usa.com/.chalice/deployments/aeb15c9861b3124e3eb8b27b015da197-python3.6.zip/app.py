from chalice import Chalice, Response
from chalice import Chalice

from ebaysdk.trading import Connection as Trading
from ebaysdk.exception import ConnectionError
from ebaysdk.finding import Connection as Finding
from boto3.dynamodb.conditions import Key, Attr

from jinja2 import Environment, PackageLoader, select_autoescape
from chalicelib import config
import boto3
import os
import json
app = Chalice(app_name='ebay')
app.debug = True

@app.route('/')
def index():
    get_categories(config.cats)
    env = get_env()
    items = get_items(config.cats[0], 12)
    template = env.get_template('index.html')
    return Response(
        body = template.render(
            title = config.title,
            items = items["searchResult"]["item"]
        ),
        status_code = 200,
        headers = {
            "Content-Type": "text/html"
        }
    )

@app.route('/main.css')
def main_css():

    template = get_template('main.css')
    return Response(
        body = template.render(
        ),
        status_code = 200,
        headers = {
            "Content-Type": "text/css"
        }
    )

@app.route('/reset.css')
def reset_css():

    template = get_template('reset.css')
    return Response(
        body = template.render(
        ),
        status_code = 200,
        headers = {
            "Content-Type": "text/css"
        }
    )

def get_items(cat, limit = 10):
    cache = "/tmp/items_cache_" + str(cat) + "_" + str(limit)
    if os.path.isfile(cache):
        with(open(cache)) as data_file:
            items = json.load(data_file)
    else:


        api = Finding(
            domain = 'svcs.ebay.com',
            appid=config.app_id,
            config_file=None,
            siteid="EBAY-US"
        )

        callData = {
            "categoryId": cat,
            "outputSelector": ["GalleryInfo","PictureURLLarge"],
            "paginationInput": {
                "entriesPerPage": limit,
                "pageNumber": 1
            }
        }

        items = api.execute('findItemsByCategory', callData).dict()
        f = open (cache, "w")
        f.write(json.dumps(items))

    return items
def get_categories(cats):
    result  = []
    for cat in cats:
        dynamodb = get_dynamodb()
        table = dynamodb.Table('ebay_categories')
        response = table.query(
            IndexName="CategoryParentID-index",
            KeyConditionExpression=Key("CategoryParentID").eq(cat)
        )
        items = response['Items']
        result += items
    return result

@app.route('/favicon.ico')
def favicon():
    return Response(body="no", status_code=404, headers={'Content-Type':'text/html'})



def get_dynamodb():
    return boto3.resource('dynamodb')

def get_template(template):
    env = get_env()
    return env.get_template(template)

def get_env():
    return Environment(
            loader=PackageLoader('chalicelib', 'templates'),
            autoescape=select_autoescape(['html', 'xml'])
        )
